#!/bin/sh
schnapps create -t post "Automatic post-update snapshot"
