#!/bin/sh
schnapps create -t pre "Automatic pre-update snapshot"
